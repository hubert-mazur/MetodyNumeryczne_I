#include <iostream>
#include "main.h"
int main()
{
	solve_AD_equation_(0, 10000);
	return 0;
}